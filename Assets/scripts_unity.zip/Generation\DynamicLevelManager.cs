using System;
using System.Collections.Generic;
using UnityEngine;

public class DynamicLevelManager : MonoBehaviour
{
    [Header("Generación Principal")]
    [SerializeField]
    private MazeGenerator mazeGenerator;

    [SerializeField]
    private MazeTilemapRenderer mazeRenderer;

    [Header("Spawners de Objetos (Asigna uno de los dos)")]
    [SerializeField]
    private LevelObjectSpawner levelObjectSpawner;

    [SerializeField]
    private MazeGameplayObjectSpawner gameplayObjectSpawner;

    [Header("Jugador (Gato) - Ajustes de Posición")]
    [Tooltip("Recomendado por rendimiento: arrastra el GameObject CatPlayer de la jerarquía de la escena.")]
    [SerializeField]
    private Transform playerTransform;

    [Tooltip("Respaldo opcional si no hay un jugador en la escena.")]
    [SerializeField]
    private GameObject playerPrefab;

    [Tooltip("Máscara de colisión para verificar obstáculos físicos en el spawn (asegúrate de incluir 'Wall')")]
    [SerializeField]
    private LayerMask obstacleLayer;

    [Header("Hacha - Ajustes de Aparición")]
    [Tooltip("Recomendado por rendimiento: arrastra el GameObject Hacha de la jerarquía de la escena.")]
    [SerializeField]
    private Transform axeTransform;

    [Tooltip("Respaldo opcional si no hay un hacha en la escena.")]
    [SerializeField]
    private GameObject axePrefab;

    [SerializeField, Min(1)]
    private int minimumAxeDistanceFromPlayer = 3;

    [Header("Contenedores de Jerarquía")]
    [SerializeField]
    private Transform itemsContainer;

    private GameObject spawnedAxeInstance;

    private void Start()
    {
        Debug.Log("DynamicLevelManager: Iniciando corrutina de generación de nivel...", this);
        StartCoroutine(StartGeneration());
    }

    private System.Collections.IEnumerator StartGeneration()
    {
        if (mazeGenerator == null || mazeRenderer == null)
        {
            Debug.LogError("DynamicLevelManager: ERROR - Faltan referencias del generador o renderizador.", this);
            yield break;
        }

        bool generationSuccessful = false;
        int maxAttempts = 40;
        MazeCellType[,] maze = null;
        int visualSeed = 0;
        Vector2Int startCell = Vector2Int.zero;

        for (int i = 1; i <= maxAttempts; i++)
        {
            Debug.Log($"DynamicLevelManager: Intento de generación #{i}...", this);
            
            // Limpiar visuales previas si las hay
            mazeRenderer.Clear();

            // 1. Generar la matriz lógica
            maze = mazeGenerator.Generate();
            visualSeed = mazeGenerator.LastUsedSeed;
            startCell = mazeGenerator.StartCell;

            // 2. Pre-calcular origen y renderizar Tilemaps (para que Unity empiece a crear las físicas)
            mazeRenderer.PreCalculateOrigin(maze);
            mazeRenderer.Render(maze, visualSeed, startCell);

            // 3. Colocar al jugador en StartCell
            Vector3 playerWorldPos = mazeRenderer.GetWorldPosition(startCell);
            SetupPlayer(playerWorldPos);

            // ESPERAR 1 FRAME FÍSICO PARA QUE SE CREEN LOS COLLIDERS DE LOS TILEMAPS
            yield return new WaitForFixedUpdate();

            // 4. Validar Físicamente el Spawn
            if (IsPlayerSpawnValid())
            {
                Debug.Log($"DynamicLevelManager: ¡Generación válida en el intento #{i}! El jugador puede moverse libremente.", this);
                generationSuccessful = true;
                break;
            }
            else
            {
                Debug.LogWarning($"DynamicLevelManager: El intento #{i} generó un jugador atascado. Regenerando...", this);
            }
        }

        if (!generationSuccessful)
        {
            Debug.LogError($"DynamicLevelManager: FATAL - No se pudo generar un mapa válido después de {maxAttempts} intentos.", this);
            yield break; // Nos rendimos
        }

        // 5. Si tuvimos éxito, inicializamos datos y spawneamos el resto
        MazeData mazeData = GetComponent<MazeData>();
        if (mazeData == null) mazeData = gameObject.AddComponent<MazeData>();
        mazeData.Initialize(maze, mazeRenderer.CurrentOrigin, mazeRenderer.LogicalCellTileSize);

        // Calcular la región principal obligatoriamente desde el punto de inicio
        mazeData.CalculateMainRegion(startCell);

        // 6. Instanciar Objetos Grandes/Destructibles
        SpawnDestructibles(maze, visualSeed, startCell, mazeData);

        // 7. Instanciar el Hacha
        Vector2Int axeCell = mazeData.SelectFurthestCell(startCell, visualSeed, minimumAxeDistanceFromPlayer);
        Vector3 axeWorldPos = mazeRenderer.GetWorldPosition(axeCell);
        SetupAxe(axeWorldPos);
    }

    private void SpawnDestructibles(MazeCellType[,] maze, int visualSeed, Vector2Int startCell, MazeData mazeData)
    {
        Vector3Int playerSpawnCell = new Vector3Int(startCell.x, startCell.y, 0);

        LevelObjectSpawner spawnerToUse = levelObjectSpawner;
        if (spawnerToUse == null)
        {
            spawnerToUse = GetComponentInChildren<LevelObjectSpawner>();
            if (spawnerToUse == null) spawnerToUse = FindObjectOfType<LevelObjectSpawner>();
        }

        if (spawnerToUse != null)
        {
            spawnerToUse.SpawnDestructibles(
                maze,
                mazeRenderer.CurrentOrigin,
                mazeRenderer.LogicalCellTileSize,
                playerSpawnCell,
                playerSpawnCell,
                visualSeed
            );
            foreach (var cell in spawnerToUse.OccupiedCells)
            {
                if (cell == playerSpawnCell) continue;
                mazeData.MarkCellsAsOccupied(new Vector2Int(cell.x, cell.y), 1, 1);
            }
            return;
        }

        // Alternative Spawner fallback
        MazeGameplayObjectSpawner altSpawner = gameplayObjectSpawner;
        if (altSpawner == null)
        {
            altSpawner = GetComponentInChildren<MazeGameplayObjectSpawner>();
            if (altSpawner == null) altSpawner = FindObjectOfType<MazeGameplayObjectSpawner>();
        }

        if (altSpawner != null)
        {
            altSpawner.SpawnDestructibles(
                maze,
                mazeRenderer.CurrentOrigin,
                mazeRenderer.LogicalCellTileSize,
                playerSpawnCell,
                playerSpawnCell,
                visualSeed
            );
            foreach (var cell in altSpawner.OccupiedCells)
            {
                if (cell == playerSpawnCell) continue;
                mazeData.MarkCellsAsOccupied(new Vector2Int(cell.x, cell.y), 1, 1);
            }
        }
    }

    private bool IsPlayerSpawnValid()
    {
        if (playerTransform == null) return false;
        
        CapsuleCollider2D col = playerTransform.GetComponent<CapsuleCollider2D>();
        if (col == null) 
        {
            Debug.LogWarning("DynamicLevelManager: El jugador no tiene CapsuleCollider2D. Asumiendo spawn válido.");
            return true;
        }

        Vector2 origin = (Vector2)playerTransform.position + col.offset;

        // Prueba 1: ¿Está el jugador físicamente DENTRO de una pared justo al spawnear?
        Collider2D directHit = Physics2D.OverlapCapsule(origin, col.size, col.direction, 0f, obstacleLayer);
        if (directHit != null)
        {
            Debug.Log($"DynamicLevelManager: Falla validación. Jugador solapado con {directHit.name}.");
            return false; 
        }

        // Prueba 2: ¿Puede el jugador moverse en CUALQUIER dirección para escapar?
        // Comprobamos tirando la cápsula un poco en las 4 direcciones.
        float distance = 0.5f; // Medio metro es suficiente para comprobar si hay salida
        Vector2[] directions = { Vector2.up, Vector2.down, Vector2.left, Vector2.right };
        int freeDirections = 0;

        foreach (var dir in directions)
        {
            RaycastHit2D castHit = Physics2D.CapsuleCast(origin, col.size, col.direction, 0f, dir, distance, obstacleLayer);
            if (castHit.collider == null)
            {
                freeDirections++;
            }
        }

        if (freeDirections == 0)
        {
            Debug.Log("DynamicLevelManager: Falla validación. Jugador atrapado en las 4 direcciones.");
            return false;
        }

        return true;
    }

    private void SetupPlayer(Vector3 spawnWorldPosition)
    {
        Transform targetTransform = playerTransform;

        if (targetTransform == null)
        {
            CatMovement movementComp = FindObjectOfType<CatMovement>();
            if (movementComp != null)
            {
                targetTransform = movementComp.transform;
            }
        }

        if (targetTransform == null && playerPrefab != null)
        {
            GameObject newPlayer = Instantiate(playerPrefab, spawnWorldPosition, Quaternion.identity);
            targetTransform = newPlayer.transform;
        }

        if (targetTransform != null)
        {
            targetTransform.position = spawnWorldPosition;
            targetTransform.gameObject.SetActive(true);
            playerTransform = targetTransform;
        }
        else
        {
            Debug.LogWarning("DynamicLevelManager: No se asignó ni Player Transform ni Player Prefab en el Inspector.", this);
        }
    }

    private void SetupAxe(Vector3 spawnWorldPosition)
    {
        if (axeTransform == null)
        {
            CollectibleItem[] items = FindObjectsOfType<CollectibleItem>();
            foreach (var item in items)
            {
                if (item.gameObject.name.ToLower().Contains("hacha") || item.gameObject.name.ToLower().Contains("axe"))
                {
                    axeTransform = item.transform;
                    break;
                }
            }
        }

        if (axeTransform != null)
        {
            axeTransform.position = spawnWorldPosition;
            axeTransform.gameObject.SetActive(true);
        }
        else if (axePrefab != null)
        {
            if (spawnedAxeInstance != null)
            {
                Destroy(spawnedAxeInstance);
            }

            Transform parent = itemsContainer != null ? itemsContainer : transform;
            spawnedAxeInstance = Instantiate(axePrefab, spawnWorldPosition, Quaternion.identity, parent);
        }
        else
        {
            Debug.LogWarning("DynamicLevelManager: No se asignó ni Axe Transform ni Axe Prefab en el Inspector.", this);
        }
    }
}
